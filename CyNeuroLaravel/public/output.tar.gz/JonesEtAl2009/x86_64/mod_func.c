#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern void _ar_reg(void);
extern void _cad_reg(void);
extern void _ca_reg(void);
extern void _cat_reg(void);
extern void _dipole_reg(void);
extern void _kca_reg(void);
extern void _km_reg(void);
extern void _pp_dipole_reg(void);

void modl_reg(){
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");

    fprintf(stderr," mod_nsgportal/ar.mod");
    fprintf(stderr," mod_nsgportal/cad.mod");
    fprintf(stderr," mod_nsgportal/ca.mod");
    fprintf(stderr," mod_nsgportal/cat.mod");
    fprintf(stderr," mod_nsgportal/dipole.mod");
    fprintf(stderr," mod_nsgportal/kca.mod");
    fprintf(stderr," mod_nsgportal/km.mod");
    fprintf(stderr," mod_nsgportal/pp_dipole.mod");
    fprintf(stderr, "\n");
  }
  _ar_reg();
  _cad_reg();
  _ca_reg();
  _cat_reg();
  _dipole_reg();
  _kca_reg();
  _km_reg();
  _pp_dipole_reg();
}
